# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Author: Jack Of Arendelle
# Credit: GD-Studio, ElevenLabs, Blender Foundation
# Description: Auto Sound Tracker for Blender Video Editing
# Date: 2025-4-13

import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import StringProperty, FloatProperty
from elevenlabs import ElevenLabs
import os
import threading
import pyaudio
import subprocess
import time

# ElevenLabs API Key
elevenlabs_default_api_key = "sk_1ec619de6c3777774097c5664aedcea1403d64fbe1feb087"
client = ElevenLabs(api_key=elevenlabs_default_api_key)

# Global variables
generate_results = []
Sound_Effect_is_playing = False
Sound_Effect_progress = 0.0
Sound_Effect_playback_process = None
Sound_Effect_total_duration = 0.0
is_generating = False

# Property Group for Sound Effect
class Sound_Effect_Props(PropertyGroup):
    text_input: StringProperty(
        name="Sound Effect Keywords",
        description="Enter keywords for the sound effect",
        default="",
    )
    duration: FloatProperty(
        name="Duration",
        description="Duration of the sound effect (0.5 to 22 seconds)",
        default=5.0,
        min=0.5,
        max=22.0,
    )
    custom_api_key: StringProperty(
        name="Custom API Key",
        description="Enter a custom ElevenLabs API key",
        default="",
    )

# Operator to Generate Sound Effect
class Generate_Sound_Effect_Operator(Operator):
    bl_idname = "autosound.generate_sound_effect"
    bl_label = "Generate Sound Effect"
    bl_description = "Generate a sound effect using ElevenLabs API"

    def execute(self, context):
        global generate_results, is_generating
        props = context.scene.sound_effect_props
        query = props.text_input.strip()
        duration = props.duration

        api_key = props.custom_api_key.strip() or elevenlabs_default_api_key

        if not query:
            self.report({'ERROR'}, "Please enter keywords!")
            return {'CANCELLED'}

        is_generating = True

        # Start a new thread for the API call
        def generate_sound():
            global is_generating
            try:
                print(f"Generating sound effect for: {query} using API key: {api_key}")

                client = ElevenLabs(api_key=api_key)  # Use the selected API key
                sound_data = client.text_to_sound_effects.convert(
                    text=query,
                    duration_seconds=duration
                )

                temp_dir = bpy.app.tempdir or os.getenv('TEMP') or os.getenv('TMP') or "/tmp"
                temp_file = os.path.join(temp_dir, f"{query.replace(' ', '_')}_{int(time.time())}.mp3")
                with open(temp_file, "wb") as f:
                    f.write(b"".join(sound_data))

                # Schedule a success message on the main thread
                def report_success():
                    global is_generating
                    generate_results.append({"name": f"{query} ({duration}s)", "sound": temp_file})
                    is_generating = False  # Reset generating state

                    # Force a UI redraw to display the updated results
                    def refresh_ui():
                        for area in bpy.context.screen.areas:
                            if area.type == 'SEQUENCE_EDITOR':
                                area.tag_redraw()

                    bpy.app.timers.register(refresh_ui, first_interval=0.1)

                    # Show a success popup
                    context.window_manager.popup_menu(
                        lambda self, context: self.layout.label(text=f"Generated sound effect: {query}"),
                        title="Success",
                        icon='INFO'
                    )

                bpy.app.timers.register(report_success, first_interval=0.1)

                print(f"Sound effect generated and saved to: {temp_file}")

            except Exception as e:
                # Capture the exception message
                error_message = str(e)

                # Schedule an error message on the main thread
                def report_error():
                    global is_generating
                    is_generating = False
                    context.window_manager.popup_menu(
                        lambda self, context: self.layout.label(text=f"Failed to generate sound effect: {error_message}"),
                        title="Error",
                        icon='ERROR'
                    )

                print(f"Error generating sound effect: {error_message}")
                bpy.app.timers.register(report_error, first_interval=0.1)

        threading.Thread(target=generate_sound, daemon=True).start()
        return {'FINISHED'}

def Sound_Effect_update_ui_progress():
    global Sound_Effect_progress, Sound_Effect_is_playing, Sound_Effect_total_duration
    if Sound_Effect_is_playing:
        bpy.context.scene.Sound_Effect_music_progress = Sound_Effect_progress
        bpy.context.scene.Sound_Effect_music_progress_label = f"[{'█' * round(Sound_Effect_progress * 10)}{'░' * (10 - round(Sound_Effect_progress * 10))}] {round(Sound_Effect_progress * 100)}% {round(Sound_Effect_total_duration * Sound_Effect_progress)}s/{round(Sound_Effect_total_duration)}s"
        return 0.1  # Update in a small time interval
    bpy.context.scene.Sound_Effect_music_progress_label = f"[{'░' * 10}]"
    return None

# Playback Functions
def Sound_Effect_play_sound(file_path):
    global Sound_Effect_playback_process, Sound_Effect_is_playing, Sound_Effect_progress, Sound_Effect_total_duration

    Sound_Effect_stop_sound()
    bpy.app.timers.register(Sound_Effect_update_ui_progress)

    def playback():
        global Sound_Effect_playback_process, Sound_Effect_is_playing, Sound_Effect_progress, Sound_Effect_total_duration
        try:
            Sound_Effect_playback_process = subprocess.Popen(
                ["ffmpeg", "-i", file_path, "-f", "s16le", "-ar", "44100", "-ac", "2", "-"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            if Sound_Effect_playback_process.stdout is None or Sound_Effect_playback_process.stderr is None:
                raise RuntimeError("Failed to initialize ffmpeg process.")

            p = pyaudio.PyAudio()
            stream = p.open(format=pyaudio.paInt16, channels=2, rate=44100, output=True)

            for line in Sound_Effect_playback_process.stderr:
                if b"Duration" in line:
                    duration_str = line.decode().split("Duration: ")[1].split(",")[0]
                    h, m, s = map(float, duration_str.split(":"))
                    Sound_Effect_total_duration = h * 3600 + m * 60 + s
                    break

            elapsed_time = 0.0
            bpy.app.timers.register(Sound_Effect_update_ui_progress)
            while True:
                data = Sound_Effect_playback_process.stdout.read(1024)
                if not data:
                    break
                stream.write(data)
                elapsed_time += 1024 / (44100 * 2 * 2)
                Sound_Effect_progress = elapsed_time / Sound_Effect_total_duration if Sound_Effect_total_duration else 0.0

            stream.stop_stream()
            stream.close()
            p.terminate()

            Sound_Effect_stop_sound()
            bpy.app.timers.register(Sound_Effect_update_ui_progress)

        except Exception as e:
            print(f"Playback failed: {e}")

    threading.Thread(target=playback, daemon=True).start()
    Sound_Effect_is_playing = True

def Sound_Effect_stop_sound():
    global Sound_Effect_playback_process, Sound_Effect_is_playing
    if Sound_Effect_playback_process:
        Sound_Effect_playback_process.terminate()
        Sound_Effect_playback_process = None
    Sound_Effect_is_playing = False
    bpy.app.timers.register(Sound_Effect_update_ui_progress)

# Operator to Stop Playback
class Stop_Sound_Effect_Operator(Operator):
    bl_idname = "autosound.stop_sound_effect"
    bl_label = "Stop Sound Effect"
    bl_description = "Stop the currently playing sound effect"

    def execute(self, context):
        global Sound_Effect_is_playing, Sound_Effect_progress

        if Sound_Effect_is_playing:
            Sound_Effect_stop_sound()
            bpy.app.timers.register(Sound_Effect_update_ui_progress)
            Sound_Effect_is_playing = False
            Sound_Effect_progress = 0.0
            context.scene.Sound_Effect_music_progress = 0.0
            self.report({'INFO'}, "Sound effect stopped.")
        else:
            self.report({'INFO'}, "No sound effect is playing.")

        return {'FINISHED'}

# Operator to Apply Sound Effect
class Apply_Sound_Effect_Operator(Operator):
    bl_idname = "autosound.apply_sound_effect"
    bl_label = "Apply Sound Effect"
    bl_description = "Apply selected sound effect to the sequence editor"

    sound_data: StringProperty()

    def execute(self, context):
        if self.sound_data:
            try:
                scene = context.scene
                sequence_editor = scene.sequence_editor
                if not sequence_editor:
                    sequence_editor = scene.sequence_editor_create()

                current_frame = scene.frame_current

                # Find the first available empty channel
                used_channels = {seq.channel for seq in sequence_editor.sequences}
                new_channel = 1
                while new_channel in used_channels:
                    new_channel += 1

                # Add the sound to the first available empty channel
                sequence_editor.sequences.new_sound(
                    name=os.path.basename(self.sound_data),
                    filepath=self.sound_data,
                    channel=new_channel,
                    frame_start=current_frame
                )
                self.report({'INFO'}, f"Applied sound effect: {self.sound_data} to the sequence editor.")
            except Exception as e:
                self.report({'ERROR'}, f"Failed to apply sound effect: {e}")
        else:
            self.report({'ERROR'}, "No sound data to apply.")
        return {'FINISHED'}

# Operator to Delete Sound Effect
class Delete_Sound_Effect_Operator(Operator):
    bl_idname = "autosound.delete_sound_effect"
    bl_label = "Delete Sound Effect"
    bl_description = "Delete the selected sound effect"

    sound_data: StringProperty()
    index: bpy.props.IntProperty()

    def execute(self, context):
        global generate_results

        if self.sound_data:
            try:
                # Delete the file
                if os.path.exists(self.sound_data):
                    os.remove(self.sound_data)
                    print(f"Deleted file: {self.sound_data}")

                # Remove the item from the generate_results list
                if 0 <= self.index < len(generate_results):
                    del generate_results[self.index]

                # Force a UI redraw to update the list
                for area in bpy.context.screen.areas:
                    if area.type == 'SEQUENCE_EDITOR':
                        area.tag_redraw()

                self.report({'INFO'}, "Sound effect deleted successfully.")
            except Exception as e:
                self.report({'ERROR'}, f"Failed to delete sound effect: {e}")
        else:
            self.report({'ERROR'}, "No sound data to delete.")
        return {'FINISHED'}

# Operator to Use Default API Key
class Use_Default_API_Operator(Operator):
    bl_idname = "autosound.use_default_api"
    bl_label = "Use Default API Key"
    bl_description = "Use Default API Key (May not work. Recommended to use your own API key.)"

    custom_api_key: StringProperty()

    def execute(self, context):
        props = context.scene.sound_effect_props
        props.custom_api_key = self.custom_api_key  # Clear the custom API key
        self.report({'INFO'}, "Using default API key.")
        return {'FINISHED'}

# Operator to Play Sound Effect
class Play_Sound_Effect_Operator(Operator):
    bl_idname = "autosound.play_sound_effect"
    bl_label = "Play Sound Effect"
    bl_description = "Play the selected sound effect"

    sound_data: StringProperty()

    def execute(self, context):
        global Sound_Effect_is_playing, Sound_Effect_progress

        if self.sound_data:
            Sound_Effect_play_sound(self.sound_data)
            self.report({'INFO'}, "Playing sound effect.")
        else:
            self.report({'ERROR'}, "No sound data to play.")
        
        return {'FINISHED'}

# Panel for Sound Effect UI
class Sound_Effect_Panel(Panel):
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_idname = "OBJECT_PT_Sound_Effect"
    bl_category = "Auto Sound Tracker"
    bl_label = "Auto Sound Effect"

    def draw(self, context):
        global generate_results, is_generating
        layout = self.layout
        props = context.scene.sound_effect_props

        # API Key Configuration Section
        layout.label(text="API Key Configuration:")
        row = layout.row(align=True)

        # Split the row into three parts: Default button, input field, and browser icon
        split = row.split(factor=0.25)  # Allocate 25% of the row to the "Default" button
        split.operator("autosound.use_default_api", text="Default", depress=not props.custom_api_key.strip())

        split = split.split(factor=0.75)  # Allocate the remaining space to the input field and browser icon
        split.prop(props, "custom_api_key", text="")
        split.operator("wm.url_open", text="", icon='URL').url = "https://elevenlabs.io/app/settings/api-keys"

        layout.separator()

        # Sound Effect Generation Section
        layout.prop(props, "text_input", text="Keywords")
        layout.prop(props, "duration", text="Duration")
        layout.operator("autosound.generate_sound_effect", text="Generate", icon='FILE_REFRESH')

        if is_generating:  # Show label when generating
            layout.label(text="Generating sound effect...", icon='TIME')

        layout.separator()

        layout.label(text="Play Control:")
        layout.operator("autosound.stop_sound_effect", text="Stop", icon='CANCEL')

        bpy.app.timers.register(Sound_Effect_update_ui_progress)
        layout.label(text=f"Progress: {context.scene.Sound_Effect_music_progress_label}")

        layout.separator()

        if generate_results:
            layout.label(text="Generated Sound Effects:")
            for i, result in enumerate(generate_results, start=1):
                row = layout.row()
                row.label(text=f"{i}. {result['name']}")
                play_op = row.operator("autosound.play_sound_effect", text="Play")
                play_op.sound_data = result["sound"]

                apply_op = row.operator("autosound.apply_sound_effect", text="Apply")
                apply_op.sound_data = result["sound"]

                delete_op = row.operator("autosound.delete_sound_effect", text="", icon='TRASH')
                delete_op.sound_data = result["sound"]
                delete_op.index = i - 1  # Pass the index of the item
        else:
            layout.label(text="No results available.")

# Register and Unregister Functions
def register():
    bpy.utils.register_class(Sound_Effect_Props)
    bpy.types.Scene.sound_effect_props = bpy.props.PointerProperty(type=Sound_Effect_Props)
    bpy.types.Scene.Sound_Effect_music_progress = bpy.props.FloatProperty(
        name="Sound Effect Music Progress",
        description="Progress of the currently playing sound effect",
        default=0.0,
        min=0.0,
        max=1.0,
    )
    bpy.types.Scene.Sound_Effect_music_progress_label = bpy.props.StringProperty(
        name="Sound Effect Music Progress Label",
        description="Elapsed and total time of the currently playing sound effect",
        default="",
    )
    bpy.utils.register_class(Generate_Sound_Effect_Operator)
    bpy.utils.register_class(Play_Sound_Effect_Operator)
    bpy.utils.register_class(Stop_Sound_Effect_Operator)
    bpy.utils.register_class(Apply_Sound_Effect_Operator)
    bpy.utils.register_class(Delete_Sound_Effect_Operator)
    bpy.utils.register_class(Use_Default_API_Operator)
    bpy.utils.register_class(Sound_Effect_Panel)

def unregister():
    bpy.utils.unregister_class(Sound_Effect_Panel)
    bpy.utils.unregister_class(Use_Default_API_Operator)
    bpy.utils.unregister_class(Delete_Sound_Effect_Operator)
    bpy.utils.unregister_class(Apply_Sound_Effect_Operator)
    bpy.utils.unregister_class(Stop_Sound_Effect_Operator)
    bpy.utils.unregister_class(Play_Sound_Effect_Operator)
    bpy.utils.unregister_class(Generate_Sound_Effect_Operator)
    del bpy.types.Scene.sound_effect_props
    del bpy.types.Scene.Sound_Effect_music_progress
    del bpy.types.Scene.Sound_Effect_music_progress_label
    bpy.utils.unregister_class(Sound_Effect_Props)