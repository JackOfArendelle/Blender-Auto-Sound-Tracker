import os
import urllib.request
import zipfile
import json
import shutil

class AutoUpdater:
    UPDATE_URL = "https://api.github.com/repos/JackOfArendelle/Blender-Auto-Sound-Tracker/releases/latest"
    DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "Downloads", "AutoSoundTrack_Update")
    ADDON_DIR = os.path.dirname(__file__)
    CURRENT_VERSION = (0, 1, 0)

    @staticmethod
    def get_latest_version_info():
        try:
            with urllib.request.urlopen(AutoUpdater.UPDATE_URL) as response:
                data = json.loads(response.read().decode())
                latest_version = tuple(map(int, data["tag_name"].lstrip("v").split(".")))
                download_url = data["assets"][0]["browser_download_url"]
                return latest_version, download_url
        except Exception as e:
            print(f"Error checking for updates: {e}")
            return None, None

    @staticmethod
    def download_and_extract_update(download_url):
        try:
            # Download the update zip file
            zip_path = os.path.join(AutoUpdater.DOWNLOAD_DIR, "update.zip")
            os.makedirs(AutoUpdater.DOWNLOAD_DIR, exist_ok=True)
            print(f"Downloading update from {download_url}...")
            urllib.request.urlretrieve(download_url, zip_path)

            # Extract the zip file
            print("Extracting update...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(AutoUpdater.DOWNLOAD_DIR)

            # Copy the new files to the add-on directory
            extracted_dir = os.path.join(AutoUpdater.DOWNLOAD_DIR, os.listdir(AutoUpdater.DOWNLOAD_DIR)[0])
            for item in os.listdir(extracted_dir):
                src = os.path.join(extracted_dir, item)
                dst = os.path.join(AutoUpdater.ADDON_DIR, item)
                if os.path.isdir(src):
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(src, dst)

            print("Update installed successfully.")
        except Exception as e:
            print(f"Error during update: {e}")
        finally:
            # Clean up
            if os.path.exists(AutoUpdater.DOWNLOAD_DIR):
                shutil.rmtree(AutoUpdater.DOWNLOAD_DIR)

    @staticmethod
    def check_and_update():
        latest_version, download_url = AutoUpdater.get_latest_version_info()
        if not latest_version or not download_url:
            print("Could not retrieve update information.")
            return

        if latest_version > AutoUpdater.CURRENT_VERSION:
            print(f"New version available: {latest_version}. Updating...")
            AutoUpdater.download_and_extract_update(download_url)
            print("Please restart Blender to apply the update.")
        else:
            print("You are already using the latest version.")