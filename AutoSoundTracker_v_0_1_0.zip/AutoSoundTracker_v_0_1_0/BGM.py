# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Author: Jack Of Arendelle
# Credit: GD-Studio, ElevenLabs, Blender Foundation
# Description: Auto Sound Tracker for Blender Video Editing
# Date: 2025-4-13

import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import StringProperty, FloatProperty
import requests
import pyaudio
import subprocess
import threading
import os
from .translation import trans

# Music sources
Music_Source = [
    {"name": "netease", "display": "Netease"},
    {"name": "tencent", "display": "Tencent"},
    {"name": "tidal", "display": "Tidal"},
    {"name": "spotify", "display": "Spotify"},
    {"name": "ytmusic", "display": "YouTube Music"},
    {"name": "qobuz", "display": "Qobuz"},
    {"name": "joox", "display": "Joox"},
    {"name": "deezer", "display": "Deezer"},
    {"name": "migu", "display": "Migu"},
    {"name": "kugou", "display": "Kugou"},
    {"name": "kuwo", "display": "Kuwo"},
    {"name": "ximalaya", "display": "Ximalaya"}
]

# Music playback state
BGM_is_playing = False
BGM_progress = 0.0
BGM_playback_process = None
BGM_total_duration = 0.0

def search_music(keyword, source="netease", count=20, pages=1):
    api_url = f"https://music-api.gdstudio.xyz/api.php?types=search&source={source}&name={keyword}&count={count}&pages={pages}"
    response = requests.get(api_url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def get_music_url(track_id, source="netease", br=999):
    api_url = f"https://music-api.gdstudio.xyz/api.php?types=url&source={source}&id={track_id}&br={br}"
    response = requests.get(api_url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def BGM_update_ui_progress():
    global BGM_progress, BGM_is_playing, BGM_total_duration
    if BGM_is_playing:
        bpy.context.scene.BGM_music_progress = BGM_progress
        bpy.context.scene.BGM_music_progress_label = f"[{'█' * round(BGM_progress * 10)}{'░' * (10 - round(BGM_progress * 10))}] {round(BGM_progress * 100)}% {round(BGM_total_duration * BGM_progress)}s/{round(BGM_total_duration)}s"
        return 0.1  # Update in a small time interval
    bpy.context.scene.BGM_music_progress_label = f"[{'░' * 10}]"
    return None

def BGM_play_music(url):
    global BGM_playback_process, BGM_is_playing

    BGM_stop_music()
    bpy.app.timers.register(BGM_update_ui_progress)

    def playback():
        global BGM_playback_process, BGM_is_playing, BGM_progress, BGM_total_duration
        try:
            BGM_playback_process = subprocess.Popen(
                ["ffmpeg", "-i", url, "-f", "s16le", "-ar", "44100", "-ac", "2", "-"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            if BGM_playback_process.stdout is None or BGM_playback_process.stderr is None:
                raise RuntimeError("Failed to initialize pipes for ffmpeg process.")

            p = pyaudio.PyAudio()

            stream = p.open(format=pyaudio.paInt16, channels=2, rate=44100, output=True)

            for line in BGM_playback_process.stderr:
                if b"Duration" in line:
                    duration_str = line.decode().split("Duration: ")[1].split(",")[0]
                    h, m, s = map(float, duration_str.split(":"))
                    BGM_total_duration = h * 3600 + m * 60 + s
                    break
            print(f"total duration: {BGM_total_duration}s")

            elapsed_time = 0.0
            bpy.app.timers.register(BGM_update_ui_progress)

            while True:
                data = BGM_playback_process.stdout.read(1024)
                if not data:
                    break
                stream.write(data)
                elapsed_time += 1024 / (44100 * 2 * 2)

                if BGM_total_duration:
                    BGM_progress = elapsed_time / BGM_total_duration

            stream.stop_stream()
            stream.close()
            p.terminate()

            BGM_stop_music()
            bpy.app.timers.register(BGM_update_ui_progress)

            BGM_playback_process.wait()
        except Exception as e:
            print(f"Playback failed: {e}")
            if BGM_playback_process and BGM_playback_process.stderr:
                error_output = BGM_playback_process.stderr.read().decode()
                print(f"FFmpeg error: {error_output}")
    
    playback_thread = threading.Thread(target=playback, daemon=True)
    playback_thread.start()
    BGM_is_playing = True

def BGM_stop_music():
    global BGM_playback_process, BGM_is_playing
    if BGM_playback_process:
        BGM_playback_process.terminate()
        BGM_playback_process = None
        BGM_is_playing = False

# Blender classes and operators
class Search_Music_Props(PropertyGroup):
    text_input: StringProperty(
        name="Search BGM",
        description="Type in music, singer, or album name",
        default="",
    )

    selected_source: StringProperty(
        name="Select Source",
        description="Selected music source",
        default="netease",
    )

    selected_name: StringProperty(
        name="Selected Name",
        description="Name of the selected music source",
        default="",
    )

    selected_music_id: StringProperty(
        name="Selected Music ID",
        description="ID of the currently selected music",
        default="",
    )

class Select_Music_Source_Operator(Operator):
    bl_idname = "autobgm.select_music_source_button"
    bl_label = "Select Music Source"
    bl_description = "Choose me"

    display: StringProperty()
    description: StringProperty()

    def execute(self, context):
        context.scene.input_box_props.selected_source = self.display
        context.scene.input_box_props.selected_name = self.description
        self.report({'INFO'}, f"Selected Music Source: {self.display}")
        return {'FINISHED'}

# Global variables for search results
search_results = []
search_results_list = []

class Search_Music_Operator(Operator):
    bl_idname = "autobgm.search_music_button"
    bl_label = "Search BGM"
    bl_description = "Go, Search"

    def execute(self, context):
        global search_results
        if not (context.scene.input_box_props.text_input).replace(" ", ""):
            self.report({'ERROR'}, "Please type in a keyword!")
            return {'CANCELLED'}

        search_results = search_music(
            context.scene.input_box_props.text_input,
            context.scene.input_box_props.selected_name,
        )

        if search_results:
            self.report({'INFO'}, f"Found {len(search_results)} results!")
        else:
            self.report({'INFO'}, "No results found.")

        return {'FINISHED'}

class Select_Music_Operator(Operator):
    global BGM_is_playing

    bl_idname = "autobgm.select_music_button"
    bl_label = "Select Music"
    bl_description = "Select me"

    action: StringProperty()  # The ID of the selected music
    source: StringProperty()  # The source of the music

    def execute(self, context):
        props = context.scene.input_box_props

        music_url_info = get_music_url(self.action, self.source)
        if music_url_info and music_url_info.get('url'):
            props.selected_music_id = self.action
            BGM_play_music(music_url_info['url'].replace("\\", ""))
            self.report({'INFO'}, f"Playing music ID: {self.action}")
        else:
            self.report({'ERROR'}, "Unable to retrieve the music URL.")

        return {'FINISHED'}

class Music_Control_Operator(Operator):
    bl_idname = "autobgm.music_control"
    bl_label = "Music Control"
    bl_description = "Stop Playing"

    def execute(self, context):
        global BGM_is_playing, BGM_progress

        if BGM_is_playing:
            BGM_stop_music()
            bpy.app.timers.register(BGM_update_ui_progress)
            BGM_is_playing = False
            BGM_progress = 0.0
            context.scene.BGM_music_progress = 0.0
            context.scene.input_box_props.selected_music_id = ""
            self.report({'INFO'}, "Music stopped.")
        else:
            self.report({'INFO'}, "No music is playing.")

        return {'FINISHED'}

class Apply_To_Soundtrack_Operator(Operator):
    bl_idname = "autobgm.apply_to_soundtrack"
    bl_label = "Apply to Sound Track"
    bl_description = "Apply the selected music to the sound track"

    def execute(self, context):
        props = context.scene.input_box_props
        music_id = props.selected_music_id
        source = props.selected_source

        if not music_id:
            self.report({'ERROR'}, "No music selected!")
            return {'CANCELLED'}

        # Get the music URL
        music_url_info = get_music_url(music_id, source)
        if not music_url_info or not music_url_info.get('url'):
            self.report({'ERROR'}, "Failed to retrieve music URL!")
            return {'CANCELLED'}

        music_url = music_url_info['url']
        tempdir = bpy.app.tempdir or os.getenv("TEMP", "/tmp")
        music_file_path = os.path.join(tempdir, f"{music_id}.mp3")

        # Download the music file
        try:
            self.report({'INFO'}, "Downloading music...")
            response = requests.get(music_url, stream=True)
            with open(music_file_path, 'wb') as music_file:
                for chunk in response.iter_content(chunk_size=1024):
                    if chunk:
                        music_file.write(chunk)
            self.report({'INFO'}, f"Music downloaded: {music_file_path}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to download music: {e}")
            return {'CANCELLED'}

        # Add the music to the sound track
        try:
            scene = context.scene
            sequence_editor = scene.sequence_editor
            if not sequence_editor:
                sequence_editor = scene.sequence_editor_create()

            current_frame = scene.frame_current

            # Find the first available empty channel
            used_channels = {seq.channel for seq in sequence_editor.sequences}
            new_channel = 1
            while new_channel in used_channels:
                new_channel += 1

            # Add the sound to the first available empty channel
            sequence_editor.sequences.new_sound(
                name=f"Music_{music_id}",
                filepath=music_file_path,
                channel=new_channel,
                frame_start=current_frame
            )
            self.report({'INFO'}, f"Music added to sound track on channel {new_channel}!")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to add music to sound track: {e}")
            return {'CANCELLED'}

        return {'FINISHED'}

class OpenMusicURL(Operator):
    bl_idname = "autobgm.open_music_url"
    bl_label = "Go to GD Studio Music Platform"
    bl_description = "Open GD Studio Music Platform URL"

    def execute(self, context):
        import webbrowser
        webbrowser.open("https://music.gdstudio.xyz/")
        self.report({'INFO'}, "Opening GD Studio Music Platform...")
        return {'FINISHED'}

class Auto_BGM(Panel):
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_idname = "OBJECT_PT_BGM"
    bl_category = "Auto Sound Tracker"
    bl_label = "Auto BGM"

    def draw(self, context):
        global search_results, BGM_is_playing, BGM_progress
        layout = self.layout
        props = context.scene.input_box_props

        # Search input
        row = layout.row(align=True)
        row.prop(props, "text_input", text=trans("Search BGM"))
        row.operator("autobgm.open_music_url", text="", icon='URL')

        # Music source buttons
        for rows in range(3):
            row = layout.row()
            for item in Music_Source[4 * rows : 4 * (rows + 1)]:
                is_selected = props.selected_source == item["display"]
                op = row.operator(
                    "autobgm.select_music_source_button",
                    text=trans(item["display"]),
                    depress=is_selected,
                )
                op.display = item["display"]
                op.description = item["name"]

        # Search button
        layout.operator("autobgm.search_music_button", text=trans("Search"), icon='VIEWZOOM')

        # Add a separator for clarity
        layout.separator()

        # Apply to sound track
        layout.label(text=trans("Apply to Sound Track:"))
        layout.operator("autobgm.apply_to_soundtrack", text=trans("Apply"), icon='CHECKMARK')

        # Add a separator for clarity
        layout.separator()

        # Music control buttons
        layout.label(text=trans("Music Control:"))
        layout.operator("autobgm.music_control", text=trans("Stop"), icon='CANCEL')

        # Progress label
        bpy.app.timers.register(BGM_update_ui_progress)
        layout.label(text=f"{trans('Progress:')} {context.scene.BGM_music_progress_label}")

        # Add a separator for clarity
        layout.separator()

        # Search results
        if search_results:
            layout.label(text=trans("Search Results:"))
            search_results_list.clear()
            for i, music in enumerate(search_results, start=1):
                display = f"{i}. {music['name']} - {music['artist']}"
                search_results_list.append({"display": display, "id": str(music["id"]), "name": music["name"], "artist": music["artist"], "album": music["album"]})
            for item in search_results_list:
                is_selected = props.selected_music_id == item["id"]
                op = layout.operator(
                    "autobgm.select_music_button",
                    text=item["display"],
                    depress=is_selected,
                )
                op.action = item["id"]  # Pass the music ID
                op.source = props.selected_source  # Pass the selected source
        else:
            layout.label(text=trans("No results to display."))

def register():
    bpy.utils.register_class(Search_Music_Props)
    bpy.types.Scene.input_box_props = bpy.props.PointerProperty(type=Search_Music_Props)
    bpy.types.Scene.BGM_music_progress = bpy.props.FloatProperty(
        name="BGM Music Progress",
        description="Progress of the currently playing BGM",
        default=0.0,
        min=0.0,
        max=1.0,
    )
    bpy.types.Scene.BGM_music_progress_label = bpy.props.StringProperty(
        name="BGM Music Progress Label",
        description="Elapsed and total time of the currently playing BGM",
        default="",
    )
    bpy.utils.register_class(Select_Music_Source_Operator)
    bpy.utils.register_class(Search_Music_Operator)
    bpy.utils.register_class(Select_Music_Operator)
    bpy.utils.register_class(Music_Control_Operator)
    bpy.utils.register_class(Apply_To_Soundtrack_Operator)
    bpy.utils.register_class(Auto_BGM)
    bpy.utils.register_class(OpenMusicURL)

def unregister():
    bpy.utils.unregister_class(Auto_BGM)
    bpy.utils.unregister_class(Music_Control_Operator)
    bpy.utils.unregister_class(Select_Music_Operator)
    bpy.utils.unregister_class(Search_Music_Operator)
    bpy.utils.unregister_class(Select_Music_Source_Operator)
    bpy.utils.unregister_class(Apply_To_Soundtrack_Operator)
    bpy.utils.unregister_class(OpenMusicURL)
    del bpy.types.Scene.input_box_props
    del bpy.types.Scene.BGM_music_progress
    del bpy.types.Scene.BGM_music_progress_label
    bpy.utils.unregister_class(Search_Music_Props)