# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Author: Jack Of Arendelle
# Credit: GD-Studio, ElevenLabs, Blender Foundation
# Description: Auto Sound Tracker for Blender Video Editing
# Date: 2025-4-13

# __init__.py
import bpy
from importlib import import_module
import subprocess
import os
import sys
import zipfile
import urllib.request
import urllib.parse
from shutil import which

class PkgInstaller:
    source = [
        "https://mirrors.aliyun.com/pypi/simple/",
        "https://pypi.tuna.tsinghua.edu.cn/simple/",
        "https://pypi.mirrors.ustc.edu.cn/simple/",
        "https://pypi.python.org/simple/",
        "https://pypi.org/simple",
    ]
    fast_url = ""

    @staticmethod
    def select_pip_source():
        if not PkgInstaller.fast_url:
            import requests

            t, PkgInstaller.fast_url = 999, PkgInstaller.source[0]
            for url in PkgInstaller.source:
                try:
                    tping = requests.get(url, timeout=1).elapsed.total_seconds()
                except Exception:
                    continue
                if tping < 0.1:
                    PkgInstaller.fast_url = url
                    break
                if tping < t:
                    t, PkgInstaller.fast_url = tping, url
        return PkgInstaller.fast_url

    @staticmethod
    def is_installed(package):
        import importlib

        try:
            return importlib.import_module(package)
        except ModuleNotFoundError:
            return False

    @staticmethod
    def prepare_pip():
        import ensurepip

        if PkgInstaller.is_installed("pip"):
            return True
        try:
            ensurepip.bootstrap()
            return True
        except BaseException:
            ...
        return False

    @staticmethod
    def try_install(*packages):
        if not PkgInstaller.prepare_pip():
            return False
        need = [pkg for pkg in packages if not PkgInstaller.is_installed(pkg)]
        from pip._internal import main # type: ignore

        url = PkgInstaller.select_pip_source() if need else ""
        for pkg in need:
            try:
                from urllib.parse import urlparse

                site = urlparse(url)
                # 避免build
                command = ["install", pkg, "-i", url, "--prefer-binary"]
                command.append("--trusted-host")
                command.append(site.netloc)
                main(command)
                if not PkgInstaller.is_installed(pkg):
                    return False
            except Exception:
                return False
        return True

# Ensure FFmpeg is installed
def ensure_ffmpeg():
    if which("ffmpeg") is None:
        print("FFmpeg not found. Attempting to install...")
        if sys.platform == "win32":
            is_64bit = sys.maxsize > 2**32
            ffmpeg_url = (
                "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
                if is_64bit else
                "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials-32.zip"
            )
            ffmpeg_zip = os.path.join(os.path.expanduser("~"), "Downloads", "ffmpeg.zip")
            ffmpeg_dir = os.path.join(os.path.expanduser("~"), "ffmpeg")

            # Download FFmpeg
            print(f"Downloading FFmpeg from {ffmpeg_url}...")
            urllib.request.urlretrieve(ffmpeg_url, ffmpeg_zip)

            # Extract FFmpeg
            print("Extracting FFmpeg...")
            with zipfile.ZipFile(ffmpeg_zip, 'r') as zip_ref:
                zip_ref.extractall(ffmpeg_dir)

            # Add FFmpeg to PATH
            os.environ["PATH"] += os.pathsep + os.path.join(ffmpeg_dir, "bin")
            print("FFmpeg installed and added to PATH.")
        else:
            raise SystemError("Please install FFmpeg manually. Visit https://ffmpeg.org/download.html for instructions.")

# Ensure dependencies before importing modules
PkgInstaller.try_install("pyaudio")
PkgInstaller.try_install("requests")
PkgInstaller.try_install("elevenlabs")
PkgInstaller.try_install("python-dotenv")
ensure_ffmpeg()

from . import translation, BGM, Credits, SoundEffect
from .auto_update import AutoUpdater

# Check for updates when the add-on is loaded
AutoUpdater.check_and_update()

# Add-on metadata
bl_info = {
    "name": "Auto Sound Tracker",
    "author": "Jack Of Arendelle",
    "version": (0, 1, 0),
    "blender": (4, 2, 8),
    "description": "Auto BGM and Sound Effect in Video Sequencer",
    "category": "Object",
}

def register():
    translation.register(__name__)
    BGM.register()
    SoundEffect.register()
    Credits.register()

def unregister():
    translation.unregister(__name__)
    BGM.unregister()
    SoundEffect.unregister()
    Credits.unregister()