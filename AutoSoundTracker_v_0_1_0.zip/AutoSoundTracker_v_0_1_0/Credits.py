# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Author: Jack Of Arendelle
# Credit: GD-Studio, ElevenLabs, Blender Foundation
# Description: Auto Sound Tracker for Blender Video Editing
# Date: 2025-4-13

import bpy
import webbrowser
from .translation import trans

class Credits_OT_URL_Open(bpy.types.Operator):
    bl_idname = "wm.url_open"
    bl_label = "Open URL"
    bl_description = "Open the friendly URL in web browser"

    url: bpy.props.StringProperty()

    def execute(self, context):
        webbrowser.open(self.url)
        return {'FINISHED'}

class Credits_Panel(bpy.types.Panel):
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_idname = "OBJECT_PT_Credits"
    bl_category = "Auto Sound Tracker"
    bl_label = "Credits"

    def draw(self, context):
        layout = self.layout

        layout.label(text=trans("For educational use only. Use at your own risk."))
        layout.label(text=trans("This add-on is under GNU 2.0 License."))

        layout.label(text=trans("Author:"))
        layout.operator("wm.url_open", text=trans("Jack Of Arendelle [Bilibili]"), icon="URL").url = "https://space.bilibili.com/477893108"
        layout.operator("wm.url_open", text=trans("Tutorial [Github]"), icon="URL").url = "https://github.com/JackOfArendelle/Blender-Auto-Sound-Tracker"
        
        layout.label(text="Credits:")
        layout.operator("wm.url_open", text=trans("GD-Studio [Bilibili]"), icon="URL").url = "https://space.bilibili.com/13715770"
        layout.operator("wm.url_open", text=trans("ElevenLabs AI Audio Platform"), icon="URL").url = "https://elevenlabs.io/"

def register():
    bpy.utils.register_class(Credits_Panel)
    bpy.utils.register_class(Credits_OT_URL_Open)

def unregister():
    bpy.utils.unregister_class(Credits_Panel)
    bpy.utils.unregister_class(Credits_OT_URL_Open)